# SARRTHI Frontend - Member 1: Authentication, Navigation and Layout

**Date:** 12 October 2026
**Module:** Login, Register, AppLayout, TopNav, Sidebar, routes

SARRTHI is an MSME tender, order, invoice and compliance dashboard (React 19, TypeScript, Vite, Tailwind CSS, shadcn/ui, TanStack Router and Query).

## Files in this submission

```
src/frontend/src/hooks/useAuth.ts
src/frontend/src/layouts/AppLayout.tsx
src/frontend/src/layouts/Sidebar.tsx
src/frontend/src/layouts/TopNav.tsx
src/frontend/src/layouts/navItems.ts
src/frontend/src/pages/LoginPage.tsx
src/frontend/src/pages/RegisterPage.tsx
src/frontend/src/routes/AppRoutes.tsx
src/frontend/src/services/api/auth.ts
```

The folder structure mirrors the main project (`src/frontend/src/...`). To run these files, place them at the same paths inside the full project and run:

```bash
pnpm install
pnpm --dir src/frontend dev
```

*Academic Project - Not an Official Government Portal.*
