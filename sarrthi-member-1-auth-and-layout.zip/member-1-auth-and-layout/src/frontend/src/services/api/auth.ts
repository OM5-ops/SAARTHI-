import { apiRequest } from "./client";

export interface AuthSession {
  token: string;
  principal: string;
  role: "admin" | "user" | "guest";
}

export function login(principal: string): Promise<AuthSession> {
  return apiRequest<AuthSession>("/api/auth/login", {
    method: "POST",
    body: { principal },
  });
}

export function logout(): Promise<void> {
  return apiRequest<void>("/api/auth/logout", { method: "POST" });
}

export function getSession(): Promise<AuthSession> {
  return apiRequest<AuthSession>("/api/auth/session");
}
