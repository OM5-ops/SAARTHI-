import { Disclaimer } from "@/components/Disclaimer";
import { Sidebar } from "@/layouts/Sidebar";
import { TopNav } from "@/layouts/TopNav";
import { useNavigate } from "@tanstack/react-router";
import { type ReactNode, useState } from "react";

export function AppLayout({ children }: { children: ReactNode }) {
  const navigate = useNavigate();
  const [search, setSearch] = useState("");

  function handleSearchChange(value: string) {
    setSearch(value);
    if (value.trim()) {
      void navigate({ to: "/tenders", search: { q: value } });
    }
  }

  return (
    <div className="flex min-h-screen bg-background">
      <Sidebar />
      <div className="flex min-w-0 flex-1 flex-col">
        <TopNav
          searchValue={search}
          onSearchChange={handleSearchChange}
          searchPlaceholder="Search tenders…"
        />
        <main className="flex-1 px-4 py-6 md:px-8">{children}</main>
        <footer className="border-t border-border bg-muted/40 px-4 py-4 md:px-8">
          <div className="flex flex-col items-start justify-between gap-2 sm:flex-row sm:items-center">
            <Disclaimer />
            <p className="text-xs text-muted-foreground">
              © {new Date().getFullYear()}. Built with love using{" "}
              <a
                href={`https://caffeine.ai?utm_source=caffeine-footer&utm_medium=referral&utm_content=${encodeURIComponent(window.location.hostname)}`}
                target="_blank"
                rel="noreferrer"
                className="font-medium text-primary underline-offset-4 hover:underline"
              >
                caffeine.ai
              </a>
            </p>
          </div>
        </footer>
      </div>
    </div>
  );
}
