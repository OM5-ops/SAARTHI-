import { Button } from "@/components/ui/button";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuLabel,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import { Input } from "@/components/ui/input";
import {
  Sheet,
  SheetContent,
  SheetHeader,
  SheetTitle,
  SheetTrigger,
} from "@/components/ui/sheet";
import { NAV_ITEMS } from "@/layouts/navItems";
import { Link } from "@tanstack/react-router";
import { Bell, Menu, Search, UserRound } from "lucide-react";
import { useState } from "react";

const NOTIFICATIONS = [
  {
    id: "overdue",
    title: "Invoice SARR/2026/0151 is overdue",
    detail: "Indian Railways — Northern Zone · 2 days past due",
  },
  {
    id: "tender",
    title: "Tender closing soon",
    detail: "IR/NZ/CH/2026/4471 · 4 days left to submit",
  },
  {
    id: "payment",
    title: "Payment received",
    detail: "₹9,00,000 recorded for SARR/2026/0155",
  },
];

export function TopNav({
  searchValue,
  onSearchChange,
  searchPlaceholder = "Search…",
}: {
  searchValue?: string;
  onSearchChange?: (value: string) => void;
  searchPlaceholder?: string;
}) {
  const [mobileOpen, setMobileOpen] = useState(false);

  return (
    <header
      data-ocid="top_nav"
      className="sticky top-0 z-30 flex h-16 items-center gap-3 border-b border-border bg-card px-4 shadow-subtle md:px-6"
    >
      <Sheet open={mobileOpen} onOpenChange={setMobileOpen}>
        <SheetTrigger asChild>
          <Button
            type="button"
            variant="ghost"
            size="icon"
            className="md:hidden"
            aria-label="Open navigation"
            data-ocid="nav.open_button"
          >
            <Menu className="size-5" aria-hidden="true" />
          </Button>
        </SheetTrigger>
        <SheetContent
          side="left"
          className="w-64 bg-sidebar text-sidebar-foreground"
        >
          <SheetHeader>
            <SheetTitle className="font-display text-sidebar-foreground">
              SARRTHI
            </SheetTitle>
          </SheetHeader>
          <nav className="mt-4 flex flex-col gap-1" aria-label="Mobile primary">
            {NAV_ITEMS.map((item) => (
              <Link
                key={item.to}
                to={item.to}
                onClick={() => setMobileOpen(false)}
                data-ocid={`nav.mobile.${item.label.toLowerCase()}`}
                className="flex items-center gap-3 rounded-md px-3 py-2 text-sm font-medium text-sidebar-foreground/80 transition-smooth hover:bg-sidebar-accent hover:text-sidebar-accent-foreground"
              >
                <item.icon className="size-5 shrink-0" aria-hidden="true" />
                {item.label}
              </Link>
            ))}
          </nav>
        </SheetContent>
      </Sheet>

      <div className="relative hidden max-w-md flex-1 sm:block">
        <Search
          className="pointer-events-none absolute left-3 top-1/2 size-4 -translate-y-1/2 text-muted-foreground"
          aria-hidden="true"
        />
        <Input
          type="search"
          value={searchValue ?? ""}
          onChange={(event) => onSearchChange?.(event.target.value)}
          placeholder={searchPlaceholder}
          aria-label="Search"
          data-ocid="search_input"
          className="pl-9"
        />
      </div>

      <div className="ml-auto flex items-center gap-1">
        <DropdownMenu>
          <DropdownMenuTrigger asChild>
            <Button
              type="button"
              variant="ghost"
              size="icon"
              aria-label="Notifications"
              data-ocid="notifications_button"
            >
              <Bell className="size-5" aria-hidden="true" />
            </Button>
          </DropdownMenuTrigger>
          <DropdownMenuContent align="end" className="w-72">
            <DropdownMenuLabel>Notifications</DropdownMenuLabel>
            <DropdownMenuSeparator />
            {NOTIFICATIONS.map((notification) => (
              <DropdownMenuItem
                key={notification.id}
                data-ocid={`notifications.item.${notification.id}`}
                className="flex-col items-start gap-0.5"
              >
                <span className="text-sm font-medium">
                  {notification.title}
                </span>
                <span className="text-xs text-muted-foreground">
                  {notification.detail}
                </span>
              </DropdownMenuItem>
            ))}
          </DropdownMenuContent>
        </DropdownMenu>

        <DropdownMenu>
          <DropdownMenuTrigger asChild>
            <Button
              type="button"
              variant="ghost"
              size="icon"
              aria-label="Profile menu"
              data-ocid="profile_button"
            >
              <UserRound className="size-5" aria-hidden="true" />
            </Button>
          </DropdownMenuTrigger>
          <DropdownMenuContent align="end" className="w-56">
            <DropdownMenuLabel>Demo Account</DropdownMenuLabel>
            <DropdownMenuSeparator />
            <DropdownMenuItem asChild data-ocid="profile.menu_item">
              <Link to="/profile">Business profile</Link>
            </DropdownMenuItem>
            <DropdownMenuItem asChild data-ocid="profile.settings_item">
              <Link to="/settings">Settings</Link>
            </DropdownMenuItem>
          </DropdownMenuContent>
        </DropdownMenu>
      </div>
    </header>
  );
}
