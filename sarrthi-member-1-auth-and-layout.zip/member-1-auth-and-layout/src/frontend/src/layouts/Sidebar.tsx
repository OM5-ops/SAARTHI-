import { NAV_ITEMS } from "@/layouts/navItems";
import { cn } from "@/lib/utils";
import { Link, useRouterState } from "@tanstack/react-router";
import { Gauge } from "lucide-react";

export function Sidebar() {
  const pathname = useRouterState({
    select: (state) => state.location.pathname,
  });

  return (
    <aside
      data-ocid="sidebar"
      className="sticky top-0 hidden h-screen w-16 shrink-0 flex-col items-center gap-1 bg-sidebar py-4 text-sidebar-foreground md:flex lg:w-60 lg:items-stretch lg:px-3"
    >
      <div className="mb-4 flex items-center gap-2 lg:px-2">
        <span className="flex size-9 items-center justify-center rounded-md bg-sidebar-primary text-sidebar-primary-foreground">
          <Gauge className="size-5" aria-hidden="true" />
        </span>
        <span className="hidden font-display text-lg font-bold tracking-tight lg:inline">
          SARRTHI
        </span>
      </div>
      <nav className="flex flex-1 flex-col gap-1" aria-label="Primary">
        {NAV_ITEMS.map((item) => {
          const isActive =
            item.to === "/" ? pathname === "/" : pathname.startsWith(item.to);
          return (
            <Link
              key={item.to}
              to={item.to}
              data-ocid={`nav.${item.label.toLowerCase()}`}
              className={cn(
                "group relative flex items-center gap-3 rounded-md px-3 py-2 text-sm font-medium transition-smooth",
                "justify-center lg:justify-start",
                isActive
                  ? "bg-sidebar-accent text-sidebar-accent-foreground"
                  : "text-sidebar-foreground/70 hover:bg-sidebar-accent/60 hover:text-sidebar-foreground",
              )}
            >
              <span
                className={cn(
                  "absolute left-0 top-1/2 h-6 w-1 -translate-y-1/2 rounded-r-full bg-sidebar-primary transition-smooth",
                  isActive ? "opacity-100" : "opacity-0",
                )}
                aria-hidden="true"
              />
              <item.icon className="size-5 shrink-0" aria-hidden="true" />
              <span className="hidden lg:inline">{item.label}</span>
            </Link>
          );
        })}
      </nav>
    </aside>
  );
}
